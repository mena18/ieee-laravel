<?php $__env->startSection('title'); ?>
	Online Courses
<?php $__env->stopSection(); ?>
<?php $__env->startSection('caption'); ?>
	<h2>ONLINE COURSES</h2>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<section class="details text-center h1" style="font-size: 100px;">
		Coming Soon
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.body',['headerClass'=>'events-hero','active'=>'online'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>