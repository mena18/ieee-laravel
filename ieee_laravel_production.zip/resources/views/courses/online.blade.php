@extends('layout.body',['headerClass'=>'events-hero','active'=>'online'])
@section('title')
	Online Courses
@endsection
@section('caption')
	<h2>ONLINE COURSES</h2>
@endsection
@section('content')
	<section class="details text-center h1" style="font-size: 100px;">
		Coming Soon
	</section>
@endsection