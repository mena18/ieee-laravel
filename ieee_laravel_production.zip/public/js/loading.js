window.onload = function () {
    $(".loading").fadeOut(1000);
    $("body").css("overflow","auto");
}
